//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Linq;
using AdvantShop.Configuration;
using AdvantShop.Controls;
using AdvantShop.FilePath;
using AdvantShop.Helpers;

namespace Templates.Mobile
{
    public partial class MasterPage : AdvantShopMasterPage
    {
        protected string phoneNumber =
            StringHelper.RemoveHTML(
                AdvantShop.Repository.CityService.GetPhone()
                    .Split(new [] {"<br>", "<br/>", "<br />"}, StringSplitOptions.RemoveEmptyEntries)
                    .FirstOrDefault() ?? string.Empty)
                .Replace("-", "")
                .Replace(" ", "")
                .Replace("(", "")
                .Replace(")", "")
                .Replace("/", "");

        protected void Page_Load(object sender, EventArgs e)
        {
            form.Action = Request.RawUrl;
            Logo.ImgSource = FoldersHelper.GetPath(FolderType.Pictures, SettingsMain.LogoImageName, false);
            phone.Visible = !string.IsNullOrEmpty(phoneNumber);
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            ClearCssJsFiles();
            TemplateName = "mobile";

            AddCssFiles(new[]
                {
                    "~/css/normalize.css",
                    "~/css/advcss/notify.css",
                    "~/css/jq/jquery-ui-1.8.17.custom.css",
                    "~/css/jq/jquery.autocomplete.css",
                    "~/css/forms.css",
                    "~/css/validator.css",
                    "~/js/plugins/jpicker/css/jpicker.css",
                    "~/js/plugins/progress/css/progress.css",
                    "~/js/plugins/compare/css/compare.css",
                    "~/js/plugins/tabs/css/tabs.css",
                    "~/js/plugins/videos/css/videos.css",
                    "~/js/plugins/flexslider/css/flexslider.css",
                    "~/js/plugins/sizeColorPickerDetails/css/sizeColorPickerDetails.css",
                    "~/js/plugins/sizeColorPickerCatalog/css/sizeColorPickerCatalog.css",
                    "~/js/jspage/details/css/details.css",
                    "~/Templates/Mobile/css/styles.css",
                    "~/Templates/Mobile/css/mobileInputs.css"
                });

            AddJsFilesTop(new[]
                {
                    "~/js/jq/jquery-1.7.1.min.js",
                    "~/js/ejs.js"
                });

            AddJsFilesBottom(new[]
                {
                    "~/js/localization/" + SettingsMain.Language + "/lang.js",
                    "~/js/string.format-1.0.js", 
                    "~/js/advantshop.js", 
                    "~/js/services/Utilities.js", 
                    "~/js/services/scriptsManager.js", 
                    "~/js/services/jsuri-1.1.1.js", 
                    "~/js/services/offers.js", 
                    "~/js/jq/jquery.cookie.js",
                    "~/js/jq/jquery.placeholder.js",
                    "~/js/jq/jquery.validate.js",
                    "~/js/jq/jquery.autocomplete.js",
                    "~/js/jq/jquery.raty.js",
                    "~/js/advjs/advNotify.js",
                    "~/js/advjs/advModal.js",
                    "~/js/advjs/advGiftCertificate.js",
                    "~/js/advjs/advUtils.js",
                    "~/js/plugins/compare/compare.js",
                    "~/js/plugins/jpicker/jpicker.js",
                    "~/js/plugins/progress/progress.js",
                    "~/js/plugins/reviews/reviews.js", 
                    "~/js/plugins/spinbox/spinbox.js",
                    "~/js/plugins/videos/videos.js",
                    "~/js/plugins/flexslider/flexslider.js",
                    "~/js/plugins/sizeColorPickerDetails/sizeColorPickerDetails.js",
                    "~/js/plugins/sizeColorPickerCatalog/sizeColorPickerCatalog.js",
                    "~/js/plugins/imagePicker/imagePicker.js", 
                    "~/js/jspage/details/details.js",
                    "~/js/dopostback.js",
                    "~/Templates/Mobile/js/plugins/cart/cart.js", 
                    "~/Templates/Mobile/js/common.js", 
                    "~/Templates/Mobile/js/validateInit.js"
                });

        }

        protected void toFullVersion_Click(object sender, EventArgs e)
        {
            MobileHelper.RedirectToDesktop(Context);
        }
    }
}