//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Linq;
using AdvantShop;
using AdvantShop.CMS;
using AdvantShop.Controls;
using AdvantShop.SEO;

namespace Templates.Mobile
{
    public partial class StaticPageView : AdvantShopClientPage
    {
        protected StaticPage page;
        protected bool hasSubPages;

        protected void Page_Load(object sender, EventArgs e)
        {
            int pageId = Page.Request["staticpageid"].TryParseInt();
            page = StaticPageService.GetStaticPage(pageId);
            if (pageId == 0 || page == null || (page != null && !page.Enabled))
            {
                Error404();
                return;
            }
            SetMeta(page.Meta, page.PageName);


            if (GoogleTagManager.Enabled)
            {
                var tagManager = ((AdvantShopMasterPage)Master).TagManager;
                tagManager.PageType = GoogleTagManager.ePageType.info;
            }
        }


        protected void Page_PreRender(object sender, EventArgs e)
        {
            lvSubPages.DataSource = StaticPageService.GetChildStaticPages(page.ID, true);
            lvSubPages.DataBind();
            hasSubPages = rightBlock.Visible = lvSubPages.Items.Any();

        }
    }
}