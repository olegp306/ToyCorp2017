//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI.WebControls;
using AdvantShop.Catalog;
using AdvantShop.Configuration;
using AdvantShop.Controls;
using AdvantShop.Core.SQL;
using AdvantShop.Customers;
using AdvantShop.SEO;
using Resources;

namespace Templates.Mobile
{
    public partial class Catalog_Page : AdvantShopClientPage
    {
        private int _categoryId;
        protected Category Category;
        protected int ProductsCount;
        protected bool Indepth;

        private SqlPaging _paging;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(Request["categoryid"]) || !Int32.TryParse(Request["categoryid"], out _categoryId))
            {
                Error404();
            }

            Category = CategoryService.GetCategory(_categoryId);
            if (Category == null || Category.Enabled == false || Category.ParentsEnabled == false)
            {
                Error404();
                return;
            }

            Indepth = Request["indepth"] == "1" || Category.DisplayChildProducts;

            _paging = new SqlPaging
            {
                TableName =
                    "[Catalog].[Product] LEFT JOIN [Catalog].[Offer] ON [Product].[ProductID] = [Offer].[ProductID] inner join Catalog.ProductCategories on ProductCategories.ProductId = [Product].[ProductID] Left JOIN [Catalog].[ProductPropertyValue] ON [Product].[ProductID] = [ProductPropertyValue].[ProductID] LEFT JOIN [Catalog].[ShoppingCart] ON [Catalog].[ShoppingCart].[OfferID] = [Catalog].[Offer].[OfferID] AND [Catalog].[ShoppingCart].[ShoppingCartType] = 3 AND [ShoppingCart].[CustomerID] = @CustomerId Left JOIN [Catalog].[Ratio] on Product.ProductId= Ratio.ProductID and Ratio.CustomerId=@CustomerId"
            };

            _paging.AddFieldsRange(
                new List<Field>
                {
                    new Field {Name = "[Product].[ProductID]", IsDistinct = true},
                    new Field
                    {
                        Name =
                            "(CASE WHEN Offer.ColorID is not null THEN (Select Count(PhotoName) From [Catalog].[Photo] WHERE ([Photo].ColorID = Offer.ColorID or [Photo].ColorID is null) and [Product].[ProductID] = [Photo].[ObjId] and Type=@Type) ELSE (Select Count(PhotoName) From [Catalog].[Photo] WHERE [Product].[ProductID] = [Photo].[ObjId] and Type=@Type) END)  AS CountPhoto"
                    },
                    new Field
                    {
                        Name =
                            "(CASE WHEN Offer.ColorID is not null THEN (Select TOP(1) PhotoName From [Catalog].[Photo] WHERE ([Photo].ColorID = Offer.ColorID or [Photo].ColorID is null) and [Product].[ProductID] = [Photo].[ObjId] and Type=@Type Order By main desc, [Photo].[PhotoSortOrder]) ELSE (Select TOP(1) PhotoName From [Catalog].[Photo] WHERE [Product].[ProductID] = [Photo].[ObjId] and Type=@Type AND [Photo].[Main] = 1) END)  AS Photo"
                    },
                    new Field
                    {
                        Name =
                            "(CASE WHEN Offer.ColorID is not null THEN (Select TOP(1) [Photo].[Description] From [Catalog].[Photo] WHERE ([Photo].ColorID = Offer.ColorID or [Photo].ColorID is null) and [Product].[ProductID] = [Photo].[ObjId] and Type=@Type Order By main desc, [Photo].[PhotoSortOrder]) ELSE (Select TOP(1) [Photo].[Description] From [Catalog].[Photo] WHERE [Product].[ProductID] = [Photo].[ObjId] and Type=@Type AND [Photo].[Main] = 1) END)  AS PhotoDesc"
                    },
                    new Field {Name = "[ProductCategories].[CategoryID]", NotInQuery = true},
                    new Field {Name = "BriefDescription"},
                    new Field {Name = "Product.ArtNo"},
                    new Field {Name = "Name"},
                    new Field
                    {
                        Name = "(CASE WHEN Price=0 THEN 0 ELSE 1 END) as TempSort",
                        Sorting = SortDirection.Descending
                    },
                    new Field {Name = "Recomended"},
                    new Field {Name = "Bestseller"},
                    new Field {Name = "New"},
                    new Field {Name = "OnSale"},
                    new Field {Name = "Discount"},
                    new Field {Name = "Offer.Main", NotInQuery = true},
                    new Field {Name = "Offer.OfferID"},
                    new Field
                    {
                        Name =
                            "(Select Max(Offer.Amount) from catalog.Offer Where ProductId=[Product].[ProductID]) as Amount"
                    },
                    new Field
                    {
                        Name =
                            "(CASE WHEN Offer.Amount <= 0 OR Offer.Amount < IsNull(MinAmount,0) THEN 0 ELSE 1 END) as TempAmountSort",
                        Sorting = SortDirection.Descending
                    },
                    new Field {Name = "MinAmount"},
                    new Field {Name = "MaxAmount"},
                    new Field {Name = "Enabled"},
                    new Field {Name = "AllowPreOrder"},
                    new Field {Name = "Ratio"},
                    new Field {Name = "RatioID"},
                    new Field {Name = "DateModified"},
                    new Field {Name = "DateAdded"},
                    new Field {Name = "ShoppingCartItemId"},
                    new Field {Name = "UrlPath"},
                    new Field {Name = !Indepth ? "[ProductCategories].[SortOrder] as SortOrder" : "0 as SortOrder"},
                    new Field {Name = "[ShoppingCart].[CustomerID]", NotInQuery = true},
                    new Field {Name = "BrandID", NotInQuery = true},
                    new Field {Name = "Offer.ProductID as Size_ProductID", NotInQuery = true},
                    new Field {Name = "Offer.ProductID as Color_ProductID", NotInQuery = true},
                    new Field {Name = "Offer.ProductID as Price_ProductID", NotInQuery = true},
                    new Field {Name = "Offer.ColorID"},
                    new Field {Name = "CategoryEnabled", NotInQuery = true},
                });

            if (SettingsCatalog.ComplexFilter)
            {
                _paging.AddFieldsRange(new List<Field>
                {
                    new Field {Name = "(select [Settings].[ProductColorsToString]([Product].[ProductID])) as Colors"},
                    new Field
                    {
                        Name =
                            "(select max (price) - min (price) from catalog.offer where offer.productid=product.productid) as MultiPrices"
                    },
                    new Field
                    {
                        Name =
                            "(select min (price) from catalog.offer where offer.productid=product.productid) as Price"
                    },
                });
            }
            else
            {
                _paging.AddFieldsRange(new List<Field>
                {
                    new Field {Name = "null as Colors"},
                    new Field {Name = "0 as MultiPrices"},
                    new Field {Name = "Price"},
                });
            }

            _paging.AddParam(new SqlParam { ParameterName = "@CustomerId", Value = CustomerContext.CustomerId.ToString() });
            _paging.AddParam(new SqlParam { ParameterName = "@Type", Value = PhotoType.Product.ToString() });

            ProductsCount = Indepth ? Category.TotalProductsCount : Category.GetProductCount();

            categoryView.CategoryID = _categoryId;
            categoryView.Visible = Category.DisplayStyle == "True" || ProductsCount == 0;

            productView.Visible = ProductsCount > 0;



            lblCategoryName.Text = _categoryId != 0 ? Category.Name : Resource.Client_MasterPage_Catalog;

            var currentMeta = Category.Meta;
            SetMeta(currentMeta, Category.Name, page: paging.CurrentPage);

            if (Category.DisplayChildProducts || Indepth)
            {
                var cfilter = new InChildCategoriesFieldFilter
                {
                    CategoryId = _categoryId.ToString(),
                    ParamName = "@CategoryID"
                };
                _paging.Fields["[ProductCategories].[CategoryID]"].Filter = cfilter;
            }
            else
            {
                var cfilter = new EqualFieldFilter { Value = _categoryId.ToString(), ParamName = "@catalog" };
                _paging.Fields["[ProductCategories].[CategoryID]"].Filter = cfilter;
            }

            _paging.Fields["Enabled"].Filter = new EqualFieldFilter { Value = "1", ParamName = "@enabled" };
            _paging.Fields["CategoryEnabled"].Filter = new EqualFieldFilter
            {
                Value = "1",
                ParamName = "@CategoryEnabled"
            };
            _paging.Fields["Offer.Main"].Filter = new EqualFieldFilter
            {
                Value = "1",
                ParamName = "@Main",
                HideInCustomData = true
            };


            switch (Category.Sorting)
            {
                case ESortOrder.AscByName:
                    _paging.Fields["Name"].Sorting = SortDirection.Ascending;
                    break;

                case ESortOrder.DescByName:
                    _paging.Fields["Name"].Sorting = SortDirection.Descending;
                    break;

                case ESortOrder.AscByPrice:
                    _paging.Fields["Price"].Sorting = SortDirection.Ascending;
                    break;

                case ESortOrder.DescByPrice:
                    _paging.Fields["Price"].Sorting = SortDirection.Descending;
                    break;

                case ESortOrder.AscByRatio:
                    _paging.Fields["Ratio"].Sorting = SortDirection.Ascending;
                    break;

                case ESortOrder.DescByRatio:
                    _paging.Fields["Ratio"].Sorting = SortDirection.Descending;
                    break;

                case ESortOrder.DescByAddingDate:
                    _paging.Fields["DateAdded"].Sorting = SortDirection.Descending;
                    break;

                default:
                    _paging.Fields["SortOrder"].Sorting = SortDirection.Ascending;
                    break;
            }
        }



        protected void Page_PreRender(object sender, EventArgs e)
        {

            _paging.ItemsPerPage = paging.CurrentPage != 0 ? SettingsCatalog.ProductsPerPage : int.MaxValue;
            _paging.CurrentPageIndex = paging.CurrentPage != 0 ? paging.CurrentPage : 1;

            var totalCount = _paging.TotalRowsCount;

            productView.ViewMode = SettingsCatalog.ProductViewMode.List;


            paging.TotalPages = _paging.PageCount;

            if ((paging.TotalPages < paging.CurrentPage && paging.CurrentPage > 1) || paging.CurrentPage < 0)
            {
                Error404();
                return;
            }

            if (paging.CurrentPage > 1)
            {
                lblCategoryName.Text = lblCategoryName.Text + Resource.Client_Catalog_PageIs + paging.CurrentPage;
            }
            var data = _paging.PageItems;
            productView.DataSource = data;
            productView.DataBind();

            if (GoogleTagManager.Enabled)
            {
                var tagManager = ((AdvantShopMasterPage)Master).TagManager;
                tagManager.PageType = GoogleTagManager.ePageType.category;
                tagManager.CatCurrentId = Category.ID;
                tagManager.CatCurrentName = Category.Name;
                tagManager.CatParentId = Category.ParentCategory.ID;
                tagManager.CatParentName = Category.ParentCategory.Name;

                tagManager.ProdIds = new List<string>();
                foreach (DataRow row in data.Rows)
                {
                    tagManager.ProdIds.Add((string)row["ArtNo"]);
                }
            }

        }
    }
}