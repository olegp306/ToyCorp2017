//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using AdvantShop.Catalog;
using AdvantShop.Configuration;
using AdvantShop.Controls;
using AdvantShop.SEO;
using Resources;

namespace Templates.Mobile
{
    public partial class Brands : AdvantShopClientPage
    {
        private const int BrandsPerPage = 8;

        private List<Brand> _dataSource;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            LoadData();
            var nmeta = new MetaInfo(string.Format("{0} - {1}", SettingsMain.ShopName, Resource.Client_Brands_Header));
            SetMeta(nmeta, string.Empty, page: paging.CurrentPage);

            header.Text = Resource.Client_Brands_Header;
            if (paging.CurrentPage > 1)
            {
                header.Text = header.Text + Resource.Client_Catalog_PageIs + paging.CurrentPage;
            }
        }

        private void LoadData()
        {
            var brands = BrandService.GetBrands(false);
           _dataSource = brands;

        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (_dataSource == null) return;
            int page = paging.CurrentPage;
            paging.TotalPages = Convert.ToInt32(Math.Ceiling((double) _dataSource.Count()/BrandsPerPage));
            if (paging.TotalPages < paging.CurrentPage || paging.CurrentPage <= 0)
            {
                Error404();
                return;
            }
            lvBrands.DataSource = _dataSource.Skip((page - 1)*BrandsPerPage).Take(BrandsPerPage).ToList();
            lvBrands.DataBind();
        }
    }
}