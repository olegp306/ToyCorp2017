//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AdvantShop;
using AdvantShop.Catalog;
using AdvantShop.Configuration;
using AdvantShop.Controls;
using AdvantShop.Core.UrlRewriter;
using AdvantShop.Customers;
using AdvantShop.Orders;
using AdvantShop.SEO;
using AdvantShop.Trial;
using Resources;

namespace Templates.Mobile
{
    public partial class ShoppingCart_Page : AdvantShopClientPage
    {
        protected CustomerGroup customerGroup;

        protected void Page_Load(object sender, EventArgs e)
        {
            customerGroup = CustomerContext.CurrentCustomer.CustomerGroup;
            lDemoWarning.Visible = Demo.IsDemoEnabled || TrialService.IsTrialEnabled;

            btnConfirm.Visible = ShoppingCartService.CurrentShoppingCart.HasItems;

           
            aCheckOut.Visible = true;

            if (!IsPostBack)
            {
                if (Request["products"].IsNotEmpty())
                {
                    foreach (var item in Request["products"].Split(";"))
                    {
                        int offerId;
                        var newItem = new ShoppingCartItem() { ShoppingCartType = ShoppingCartType.ShoppingCart, CustomerId = CustomerContext.CustomerId };

                        var parts = item.Split("-");
                        if (parts.Length > 0 && (offerId = parts[0].TryParseInt(0)) != 0 && OfferService.GetOffer(offerId) != null)
                        {
                            newItem.OfferId = offerId;
                        }
                        else
                        {
                            continue;
                        }

                        if (parts.Length > 1)
                        {
                            newItem.Amount = parts[1].TryParseFloat();
                        }
                        else
                        {
                            newItem.Amount = 1;
                        }

                        var currentItem = ShoppingCartService.CurrentShoppingCart.FirstOrDefault(shpCartitem => shpCartitem.OfferId == newItem.OfferId);

                        if (currentItem != null)
                        {
                            currentItem.Amount = newItem.Amount;
                            ShoppingCartService.UpdateShoppingCartItem(currentItem);
                        }
                        else
                        {
                            ShoppingCartService.AddShoppingCartItem(newItem);
                        }
                    }
                    Response.Redirect("~/shoppingcart.aspx");
                    return;
                }

                UpdateBasket();
                SetMeta(
                    new MetaInfo(string.Format("{0} - {1}", SettingsMain.ShopName,
                                               Resource.Client_ShoppingCart_ShoppingCart)), string.Empty);

                if (GoogleTagManager.Enabled)
                {
                    var tagManager = ((AdvantShopMasterPage)Master).TagManager;
                    tagManager.PageType = GoogleTagManager.ePageType.cart;
                    tagManager.ProdIds = ShoppingCartService.CurrentShoppingCart.Select(item => item.Offer.ArtNo).ToList();
                    tagManager.TotalValue = ShoppingCartService.CurrentShoppingCart.TotalPrice;
                }
            }
            //relatedProducts.ProductIds = ShoppingCartService.CurrentShoppingCart.Where(p => p.ItemType == ShoppingCartItem.EnumItemType.Product).Select(p => p.EntityId).ToList();
        }



        public void UpdateBasket()
        {
            var shpCart = ShoppingCartService.CurrentShoppingCart;

            if (shpCart.HasItems)
            {
                lblEmpty.Visible = false;
            }
            else
            {
                dvOrderMerged.Visible = false;
                
                lblEmpty.Visible = true;
            }
        }


        protected void btnConfirmOrder_Click(object sender, EventArgs e)
        {
            var shoppingCart = ShoppingCartService.CurrentShoppingCart;

            if (!shoppingCart.CanOrder)
            {
                UpdateBasket();
            }
            else
            {
                Response.Redirect("~/OrderConfirmation.aspx");
            }
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            UpdateBasket();
        }
    }
}