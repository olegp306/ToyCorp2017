//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using AdvantShop;
using AdvantShop.Catalog;
using AdvantShop.Controls;


namespace Templates.Mobile
{
    public partial class BrandView : AdvantShopClientPage
    {
        protected Brand brand;

        protected void Page_Load(object sender, EventArgs e)
        {
            int brandId = 0;

            if (!int.TryParse(Request["brandid"], out brandId) || (brand = BrandService.GetBrandById(brandId)) == null ||
                !brand.Enabled)
            {
                Error404();
            }
            else
            {
                divBrandSiteUrl.Visible = brand.BrandSiteUrl.IsNotEmpty();
            }
            
            SetMeta(brand.Meta, brand.Name);
        }


    }
}