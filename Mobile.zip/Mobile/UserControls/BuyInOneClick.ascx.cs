//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using AdvantShop.Catalog;
using AdvantShop.Customers;
using System.Collections.Generic;
using AdvantShop.Orders;

namespace Templates.Mobile.UserControls
{
    public partial class UserControls_BuyInOneClick : System.Web.UI.UserControl
    {
        public int ProductId;
        public List<CustomOption> CustomOptions;
        public List<OptionItem> SelectedOptions;
        public bool isShoppingCart = false;
        public BuyInOneclickPage pageEnum;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!isShoppingCart)
            {
                hfProductId.Value = ProductId.ToString();
                txtPhone.Text = CustomerContext.CurrentCustomer.Phone;
                txtName.Text = CustomerContext.CurrentCustomer.FirstName + " " +
                               CustomerContext.CurrentCustomer.LastName;
            }

            if (Request.Url.AbsolutePath.ToLower().Contains("details"))
            {
                pageEnum = BuyInOneclickPage.details;
            }
            else if (Request.Url.AbsolutePath.ToLower().Contains("shoppingcart"))
            {
                pageEnum = BuyInOneclickPage.shoppingcart;
            }

        }
    }
}