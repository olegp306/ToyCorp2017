//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using AdvantShop.CMS;
using AdvantShop.Customers;

namespace Templates.Mobile.UserControls.MasterPage
{
    public partial class MenuTopLayer : System.Web.UI.UserControl
    {
        protected string GetHtml()
        {
            string result = string.Empty;

            foreach (var mItem in MenuService.GetEnabledChildMenuItemsByParentId(0, MenuService.EMenuType.Top,
                                                    CustomerContext.CurrentCustomer.RegistredUser
                                                        ? EMenuItemShowMode.Authorized
                                                        : EMenuItemShowMode.NotAuthorized))
            {
                result +=
                    string.Format(
                        "<li><div class=\"txt-container\"><div class=\"btn-text\"><a href=\"{0}\" >{1}</a></div><span class=\"icon\">&nbsp;</span></div> </li>\n",
                        mItem.MenuItemUrlPath,
                        mItem.MenuItemName);
            }

            return result;
        }
    }
}