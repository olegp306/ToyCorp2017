//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using AdvantShop.CMS;

namespace Templates.Mobile.UserControls.MasterPage
{
    public partial class MenuTop : System.Web.UI.UserControl
    {
        protected string GetHtml()
        {

            string result = string.Empty;

            foreach (
                var mItem in
                    MenuService.GetEnabledChildMenuItemsByParentId(0, MenuService.EMenuType.Top,
                        AdvantShop.Customers.CustomerContext.CurrentCustomer.RegistredUser
                            ? EMenuItemShowMode.Authorized
                            : EMenuItemShowMode.NotAuthorized))
            {
                result += string.Format("<option value=\"{0}\">{1}</option>\n",

                    mItem.MenuItemUrlPath,

                    mItem.MenuItemName);
            }

            return result;
        }
    }
}