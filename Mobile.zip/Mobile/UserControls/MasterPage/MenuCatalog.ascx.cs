using System;
using System.Linq;
using System.Text;
using AdvantShop;
using AdvantShop.Catalog;
using AdvantShop.Core.UrlRewriter;
using AdvantShop.FilePath;


//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

namespace Templates.Mobile.UserControls.MasterPage
{
    public partial class MenuCatalog : System.Web.UI.UserControl
    {
        private int _selectedCategoryId;

        protected void Page_Load(object sender, EventArgs e)
        {

            int productID = Request["productid"].TryParseInt();
            int currentCategory = 0;
            if (productID != 0)
            {
                var firstCategory = ProductService.GetCategoriesByProductId(productID).FirstOrDefault();
                if (firstCategory != null)
                    currentCategory = firstCategory.CategoryId;
            }
            else
            {
                currentCategory = Request["categoryid"].TryParseInt();
            }

            if (currentCategory != 0)
            {
                var rootcats = CategoryService.GetParentCategories(currentCategory);
                if (rootcats.Count > 0)
                {
                    _selectedCategoryId = rootcats.Last().CategoryId;
                }
            }

        }


        public string GetMenu()
        {
            //var cacheName = "MenuCatalog" + _selectedCategoryId;
            //if (CacheManager.Contains(cacheName))
            //{
            //    return CacheManager.Get<string>(cacheName);
            //}

            var result = new StringBuilder();

            var rootCategories =
                CategoryService.GetChildCategoriesByCategoryIdForMenu(0).Where(cat => cat.Enabled).ToList();
            foreach (Category t in rootCategories)
            {
                result.AppendFormat(
                    "<li class=\"category-item\"><a class=\"cat-name image\" href=\"{0}\"><span class=\"image-container\"><img src=\"{2}\" class=\"cat-image\" /></span></a><a href=\"{0}\" class=\"cat-name text\" >{1}</a></li>",
                    UrlService.GetLink(ParamType.Category, t.UrlPath, t.CategoryId),
                    t.Name,
                    t.MiniPicture == null
                        ? "images/nophoto_small.jpg"
                        : FoldersHelper.GetImageCategoryPath(CategoryImageType.Small, t.MiniPicture.PhotoName, false));
            }

            var resultString = result.ToString();
            //CacheManager.Insert<string>(cacheName, resultString);
            return resultString;
        }
    }
}