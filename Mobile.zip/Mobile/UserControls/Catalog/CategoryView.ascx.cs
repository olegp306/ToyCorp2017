//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using AdvantShop;
using AdvantShop.Catalog;
using AdvantShop.Configuration;
using AdvantShop.FilePath;

namespace Templates.Mobile.UserControls.Catalog
{
    public partial class CategoryView : UserControl
    {
        public int CategoryID { set; get; }
        protected bool DisplayProductsCount = SettingsCatalog.ShowProductsCount;

        protected void Page_Load(object sender, EventArgs e)
        {
            var categories =
                CategoryService.GetChildCategoriesByCategoryId(CategoryID, false)
                    .Where(cat => cat.Enabled && cat.ParentsEnabled);
            lvCategory.DataSource = categories;
            lvCategory.DataBind();
        }

        protected string RenderCategoryImage(string imageUrl, int categoryId, string urlPath, string categoryName)
        {
            if (imageUrl.IsNullOrEmpty())
                return string.Empty;
            return
                string.Format(
                    "<span class='image-container'><img src=\"{0}\" class=\"cat-image\" alt=\"{1}\" title=\"{1}\"  /></span>",

                    FoldersHelper.GetImageCategoryPath(CategoryImageType.Small, imageUrl, false),
                    HttpUtility.HtmlEncode(categoryName));
        }
    }
}