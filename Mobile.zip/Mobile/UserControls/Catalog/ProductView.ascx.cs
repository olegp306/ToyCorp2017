//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using AdvantShop;
using AdvantShop.BonusSystem;
using AdvantShop.Catalog;
using AdvantShop.Configuration;
using AdvantShop.Customers;
using AdvantShop.FilePath;
using AdvantShop.Modules;
using AdvantShop.Modules.Interfaces;
using Resources;

namespace Templates.Mobile.UserControls.Catalog
{
    public partial class ProductView : UserControl
    {
        public object DataSource { set; get; }
        public SettingsCatalog.ProductViewMode ViewMode { set; get; }
        public bool HasProducts { private set; get; }

        protected bool EnableRating = SettingsCatalog.EnableProductRating;
        protected bool EnableCompare = SettingsCatalog.EnableCompareProducts;
        protected CustomerGroup customerGroup = CustomerContext.CurrentCustomer.CustomerGroup;
        protected int ImageWidth = SettingsPictureSize.SmallProductImageWidth;
        protected int ImageHeightSmall = SettingsPictureSize.SmallProductImageHeight;
        protected int ImageHeightXSmall = SettingsPictureSize.XSmallProductImageHeight;

        protected bool DisplayBuyButton = SettingsCatalog.DisplayBuyButton;
        protected bool DisplayMoreButton = SettingsCatalog.DisplayMoreButton;
        protected bool DisplayPreOrderButton = SettingsCatalog.DisplayPreOrderButton;

        protected string BuyButtonText = SettingsCatalog.BuyButtonText;
        protected string MoreButtonText = SettingsCatalog.MoreButtonText;
        protected string PreOrderButtonText = SettingsCatalog.PreOrderButtonText;


        private float _discountByTime = DiscountByTimeService.GetDiscountByTime();
        private List<ProductDiscount> _productDiscountModels = null;
        private List<ProductLabel> _customLabels = null;


        protected void Page_Load(object sender, EventArgs e)
        {
            LoadModules();
        }


        protected string RenderPictureTag(string urlPhoto, string urlPath, string photoDesc, string productName)
        {
            string strFormat = string.Empty;

            string alt = photoDesc.IsNotEmpty() ? photoDesc : productName;

            switch (ViewMode)
            {

                case SettingsCatalog.ProductViewMode.List:
                    strFormat =
                        string.Format("<a href=\"{0}\"><img src=\"{1}\" alt=\"{2}\" class=\"scp-img p-photo\" /></a>",
                            urlPath,
                            FoldersHelper.GetImageProductPath(ProductImageType.Small, urlPhoto, false),
                            HttpUtility.HtmlEncode(alt));
                    break;

            }
            return strFormat;
        }

        protected string RenderPriceTag(int productId, float price, float discount, float multiPrice, bool showBonuses = false)
        {
            float totalDiscount = discount != 0 ? discount : _discountByTime;

            if (_productDiscountModels != null)
            {
                var prodDiscount = _productDiscountModels.Find(d => d.ProductId == productId);
                if (prodDiscount != null)
                {
                    totalDiscount = prodDiscount.Discount;
                }
            }

            string productPrice;

            if (multiPrice == 0)
            {
                productPrice = CatalogService.RenderPrice(price, totalDiscount, false, customerGroup);
            }
            else
            {
                productPrice = Resource.Client_Catalog_From + " " +
                               CatalogService.RenderPrice(price, totalDiscount, false, customerGroup, isWrap: true);
            }

            return productPrice;
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            switch (ViewMode)
            {

                case SettingsCatalog.ProductViewMode.List:
                    mvProducts.SetActiveView(viewList);
                    lvList.DataSource = DataSource;
                    lvList.DataBind();
                    HasProducts = lvList.Items.Any();
                    break;
            }
        }

        private void LoadModules()
        {
            var discountModule = AttachedModules.GetModules<IDiscount>().FirstOrDefault();
            if (discountModule != null)
            {
                var classInstance = (IDiscount)Activator.CreateInstance(discountModule);
                _productDiscountModels = classInstance.GetProductDiscountsList();
            }

            _customLabels = new List<ProductLabel>();
            foreach (var labelModule in AttachedModules.GetModules<ILabel>())
            {
                var classInstance = (ILabel)Activator.CreateInstance(labelModule);
                var labelCode = classInstance.GetLabel();
                if (labelCode != null)
                    _customLabels.Add(labelCode);
            }
        }

    }
}