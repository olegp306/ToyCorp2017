using System;
using System.Linq;
using System.Web.UI;
using AdvantShop;
using AdvantShop.Catalog;

namespace Templates.Mobile.UserControls.Details
{
    public partial class ProductPhotoView : UserControl
    {
        public Product Product { set; get; }
        protected Photo MainPhoto { set; get; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Product.ProductPhotos.Any())
            {

                Offer currentOffer = OfferService.GetMainOffer(Product.Offers, Product.AllowPreOrder,
                    Request["color"].TryParseInt(true), Request["size"].TryParseInt(true));

                if (currentOffer != null)
                {
                    MainPhoto = currentOffer.Photo;
                }
                else
                {
                    MainPhoto =
                        Product.ProductPhotos.OrderByDescending(item => item.Main)
                            .ThenBy(item => item.PhotoSortOrder)
                            .FirstOrDefault(item => item.Main) ?? new Photo(0, Product.ProductId, PhotoType.Product);
                }

                if (MainPhoto == null)
                {
                    //nophoto object
                    MainPhoto = new Photo(0, Product.ProductId, PhotoType.Product)
                    {
                        PhotoName = ""
                    };
                }

                lvPhotos.DataSource = Product.ProductPhotos;
                lvPhotos.DataBind();

                carouselDetails.Visible = lvPhotos.Items.Count > 1 || Product.Offers.Count > 1;
            }
            else
            {
                MainPhoto = new Photo(0, Product.ProductId, PhotoType.Product)
                {
                    PhotoName = ""
                };
            }

        }
    }
}