$(function(){
	 advantshopListView();
});

function advantshopListView(){
	
	var $elems = $("input[type='radio'][data-role='none'],input[type='checkbox'][data-role='none']");
	
	if(!$elems.length){
		return;	
	}
	
	advantshopListView.prototype.getLabelsSelected($elems).addClass("selected");
	
	advantshopListView.prototype.bindEvent($elems);
};

advantshopListView.prototype.getLabelsSelected = function($elems){
	var inputSelected = $elems.filter(":checked"); 
	var labels = $("label");
	var labelsSelected = $([]);
	var lbl; 
	
	inputSelected.each(function(){
		lbl = labels.filter("[for='" + this.id + "']");
		
		if(lbl.length){
			labelsSelected = labelsSelected.add(lbl);
		}
	});
	
	return labelsSelected;
};
advantshopListView.prototype.getLabelsByGroup = function($elems, name){
	var $elemsGroup = $elems.filter("[name='" + name + "']");
	var labels = $("label");
	var labelsGroup = $([]);
	var lbl;
	
	$elemsGroup.each(function(){
		lbl = labels.filter("[for='" + this.id + "']");
		
		if(lbl.length){
			labelsGroup = labelsGroup.add(lbl);
		};
	});
	
	return labelsGroup;
};
advantshopListView.prototype.bindEvent = function($elems){
	var labelCurrent;
	var labels;
	
	$elems.live("click", function(){
		
		labels = advantshopListView.prototype.getLabelsByGroup($elems, this.getAttribute("name"));
		labels.removeClass("selected");
		
		labelCurrent = advantshopListView.prototype.getLabelsSelected($(this));
		labelCurrent.addClass("selected");
	});
};