//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using AdvantShop;
using AdvantShop.BonusSystem;
using AdvantShop.Catalog;
using AdvantShop.CMS;
using AdvantShop.Configuration;
using AdvantShop.Controls;
using AdvantShop.Core;
using AdvantShop.Core.UrlRewriter;
using AdvantShop.Customers;
using AdvantShop.Modules;
using AdvantShop.Modules.Interfaces;
using AdvantShop.Orders;
using AdvantShop.Security;
using AdvantShop.SEO;
using Resources;
using AdvantShop.Payment;
using System.Web.UI.WebControls;

namespace Templates.Mobile
{
    public partial class Details : AdvantShopClientPage
    {
        #region Fields

        protected Product CurrentProduct;
        protected Offer CurrentOffer;
        protected Brand CurrentBrand;
        protected MetaInfo metaInfo;

        private int _productId;
        protected int ProductId
        {
            get { return _productId != 0 ? _productId : (_productId = Request["productid"].TryParseInt()); }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (ProductId == 0)
            {
                Error404();
                return;
            }

            //if not have category
            if (ProductService.GetCountOfCategoriesByProductId(ProductId) == 0)
            {
                Error404();
                return;
            }

            // --- Check product exist ------------------------
            CurrentProduct = ProductService.GetProduct(ProductId);

            if (CurrentProduct == null || CurrentProduct.Enabled == false || CurrentProduct.CategoryEnabled == false)
            {
                Error404();
                return;
            }

            btnAdd.Text = SettingsCatalog.BuyButtonText;
            btnOrderByRequest.Text = SettingsCatalog.PreOrderButtonText;

            CurrentOffer = OfferService.GetMainOffer(CurrentProduct.Offers, CurrentProduct.AllowPreOrder, Request["color"].TryParseInt(true), Request["size"].TryParseInt(true));

            if (CurrentOffer != null)
            {
                sizeColorPicker.SelectedOfferId = CurrentOffer.OfferId;
            }
            else
            {
                pnlPrice.Visible = false;
            }

            sizeColorPicker.ProductId = ProductId;


            rating.ProductId = CurrentProduct.ID;
            rating.Rating = CurrentProduct.Ratio;
            rating.ShowRating = SettingsCatalog.EnableProductRating;
            rating.ReadOnly = RatingService.DoesUserVote(ProductId, CustomerContext.CustomerId);


            CurrentBrand = CurrentProduct.Brand;

            productPropertiesView.ProductId = ProductId;

            productPhotoView.Product = CurrentProduct;

            RecentlyViewService.SetRecentlyView(CustomerContext.CustomerId, ProductId);

            productReviews.EntityType = EntityType.Product;
            productReviews.EntityId = ProductId;

            int reviewsCount = SettingsCatalog.ModerateReviews
                                   ? ReviewService.GetCheckedReviewsCount(ProductId, EntityType.Product)
                                   : ReviewService.GetReviewsCount(ProductId, EntityType.Product);
            if (reviewsCount > 0)
            {
                lReviewsCount.Text = string.Format("({0})", reviewsCount);
            }

            metaInfo = SetMeta(CurrentProduct.Meta, CurrentProduct.Name,
                    CategoryService.GetCategory(CurrentProduct.CategoryId).Name,
                    CurrentProduct.Brand != null ? CurrentProduct.Brand.Name : string.Empty);

            if (SettingsSEO.ProductAdditionalDescription.IsNotEmpty())
            {
                liAdditionalDescription.Text =
                    GlobalStringVariableService.TranslateExpression(
                        SettingsSEO.ProductAdditionalDescription, MetaType.Product, CurrentProduct.Name,
                        CategoryService.GetCategory(CurrentProduct.CategoryId).Name,
                        CurrentProduct.Brand != null ? CurrentProduct.Brand.Name : string.Empty);
            }

            LoadModules();

            if (GoogleTagManager.Enabled)
            {
                var tagManager = ((AdvantShopMasterPage)Master).TagManager;
                tagManager.PageType = GoogleTagManager.ePageType.product;
                tagManager.ProdId = CurrentOffer != null ? CurrentOffer.ArtNo : CurrentProduct.ArtNo;
                tagManager.ProdName = CurrentProduct.Name;
                tagManager.ProdValue = CurrentOffer != null ? CurrentOffer.Price : 0;
                tagManager.CatCurrentId = CurrentProduct.MainCategory.ID;
                tagManager.CatCurrentName = CurrentProduct.MainCategory.Name;
            }
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            GetOffer();
        }

        protected string RenderSpinBox()
        {
            return
                string.Format(
                    "<input class=\"spinbox\" data-plugin=\"spinbox\" type=\"text\" id=\"txtAmount\" value=\"{0}\" data-spinbox-options=\"{{min:{0},max:{1},step:{2}}}\"/>",
                    CurrentProduct.MinAmount != null ? CurrentProduct.MinAmount.ToString().Replace(",", ".") : "1",
                    CurrentProduct.MaxAmount != null
                        ? CurrentProduct.MaxAmount.ToString().Replace(",", ".")
                        : Int16.MaxValue.ToString(),
                    CurrentProduct.Multiplicity.ToString().Replace(",", "."));
        }

        private void GetOffer()
        {
            if (CurrentOffer != null)
            {
                bool isMultiOffers = CurrentProduct.Offers.Count > 1;
                bool isAvailable = CurrentOffer.Amount > 0;
                bool isUnavalable = CurrentOffer.Amount <= 0;

                btnOrderByRequest.Attributes["data-offerid"] = CurrentOffer.OfferId.ToString();

                btnAdd.Attributes["data-cart-add-productid"] = ProductId.ToString();
                btnAdd.Attributes["data-cart-add-offerid"] = CurrentOffer.OfferId.ToString();
                btnAdd.Attributes["data-offerid"] = CurrentOffer.OfferId.ToString();

                ButtonSetVisible(btnOrderByRequest, (isUnavalable || CurrentOffer.Price == 0) && CurrentProduct.AllowPreOrder, isMultiOffers);
                ButtonSetVisible(btnAdd, CurrentOffer.Price > 0 && isAvailable, isMultiOffers);

                ShowCreditButtons(isMultiOffers);

                LoadBonusCard();
                LoadShippings();
            }
        }

        private void LoadBonusCard()
        {
            if (!BonusSystem.IsActive || CurrentOffer.Price <= 0)
                return;

            var bonusCard = BonusSystemService.GetCard(CustomerContext.CurrentCustomer.BonusCardNumber);
            if (bonusCard != null)
            {
                lblProductBonus.Text =
                    CatalogService.RenderBonusPrice(bonusCard.BonusPercent, CurrentOffer.Price,
                        CurrentProduct.CalculableDiscount, CustomerContext.CurrentCustomer.CustomerGroup, CustomOptionsService.SerializeToXml(productCustomOptions.CustomOptions, productCustomOptions.SelectedOptions));
            }
            else if (BonusSystem.BonusFirstPercent != 0)
            {
                lblProductBonus.Text =
                    CatalogService.RenderBonusPrice(BonusSystem.BonusFirstPercent, CurrentOffer.Price,
                        CurrentProduct.CalculableDiscount, CustomerContext.CurrentCustomer.CustomerGroup, CustomOptionsService.SerializeToXml(productCustomOptions.CustomOptions, productCustomOptions.SelectedOptions));
            }
        }

        private void LoadShippings()
        {
            //if (SettingsDesign.ShowShippingsMethodsInDetails != SettingsDesign.eShowShippingsInDetails.Never)
            //{
            //    liShipping.Text = string.Format("<div class=\"js-details-delivery\" data-value=\"{0}\"></div>",
            //                                        (int)SettingsDesign.ShowShippingsMethodsInDetails);
            //}
        }

        #region Modules

        private void LoadModules()
        {
            LoadTabModules();
            LoadProductInformationModules();

            ltrlRightColumnModules.Text = ModulesRenderer.RenderDetailsModulesToRightColumn();
        }

        private void LoadTabModules()
        {
            var listDetailsTabs = new List<ITab>();

            foreach (var detailsTabsModule in AttachedModules.GetModules<IProductTabs>())
            {
                var classInstance = (IProductTabs)Activator.CreateInstance(detailsTabsModule, null);
                listDetailsTabs.AddRange(classInstance.GetProductDetailsTabsCollection(CurrentProduct.ProductId));
            }

            lvTabsBodies.DataSource = listDetailsTabs;
            lvTabsBodies.DataBind();
        }

        private void LoadProductInformationModules()
        {
            foreach (var module in AttachedModules.GetModules<IModuleDetails>())
            {
                var classInstance = (IModuleDetails)Activator.CreateInstance(module, null);
                liProductInformation.Text += classInstance.RenderToProductInformation(CurrentProduct.ProductId);
            }
        }

        #endregion

        #region "Show/hide buttons"

        private void ShowCreditButtons(bool isMultiOffers)
        {
            var creditPayment = PaymentService.GetCreditPaymentMethods().FirstOrDefault();
            if (creditPayment != null && CurrentOffer != null)
            {
                btnAddCredit.Attributes["data-cart-add-productid"] = ProductId.ToString();
                btnAddCredit.Attributes["data-cart-add-offerid"] = CurrentOffer.OfferId.ToString();
                btnAddCredit.Attributes["data-cart-payment"] = creditPayment.PaymentMethodId.ToString();
                btnAddCredit.Attributes["data-cart-minprice"] = creditPayment.MinimumPrice.ToString();

                var productPrice = CatalogService.CalculateProductPrice(CurrentOffer.Price,
                            CurrentProduct.CalculableDiscount,
                            CustomerContext.CurrentCustomer.CustomerGroup,
                            CustomOptionsService.DeserializeFromXml(
                                CustomOptionsService.SerializeToXml(productCustomOptions.CustomOptions, productCustomOptions.SelectedOptions)));

                var isVisible = productPrice > creditPayment.MinimumPrice && CurrentOffer.Amount > 0;

                ButtonSetVisible(btnAddCredit, isVisible, isMultiOffers);
                ButtonSetVisible(lblFirstPaymentNote, isVisible && creditPayment.MinimumPrice > 0, isMultiOffers);
                ButtonSetVisible(lblFirstPayment, isVisible && creditPayment.MinimumPrice > 0, isMultiOffers);

                hfFirstPaymentPercent.Value = creditPayment.FirstPayment.ToString();

                lblFirstPayment.Text = creditPayment.FirstPayment > 0
                    ? CatalogService.GetStringPrice(productPrice * creditPayment.FirstPayment / 100) + @"*"
                    : string.Format("<div class=\"price\">{0}*</div>", Resource.Client_Details_WithoutFirstPayment);
            }
            else
            {
                ButtonSetVisible(btnAddCredit, false, false);
                ButtonSetVisible(lblFirstPaymentNote, false, false);
                ButtonSetVisible(lblFirstPayment, false, false);
            }
        }

        private void ButtonHide(WebControl btn, bool isMultiOffers)
        {
            if (isMultiOffers == true)
            {
                btn.Attributes["style"] = "display:none;";
            }
            else
            {
                btn.Visible = false;
            }
        }

        private void ButtonShow(WebControl btn, bool isMultiOffers)
        {
            if (isMultiOffers == true)
            {
                btn.Attributes["style"] = "display:inline-block;";
            }
            else
            {
                btn.Visible = true;
            }
        }

        private void ButtonSetVisible(WebControl btn, bool isVisible, bool isMultiOffers)
        {
            if (isVisible == true)
            {
                ButtonShow(btn, isMultiOffers);
            }
            else
            {
                ButtonHide(btn, isMultiOffers);
            }
        }

        #endregion
    }
}