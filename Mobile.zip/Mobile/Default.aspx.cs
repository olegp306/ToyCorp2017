//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using AdvantShop.Controls;


namespace Templates.Mobile
{
    public partial class Default : AdvantShopClientPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SetMeta(null, string.Empty);
        }
    }
}