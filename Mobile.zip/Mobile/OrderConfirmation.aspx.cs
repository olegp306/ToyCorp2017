﻿//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AdvantShop;
using AdvantShop.Catalog;
using AdvantShop.Configuration;
using AdvantShop.Controls;
using AdvantShop.Customers;
using AdvantShop.Mails;
using AdvantShop.Modules;
using AdvantShop.Orders;
using AdvantShop.Repository.Currencies;
using AdvantShop.SEO;


namespace Templates.Mobile
{
    public partial class OrderConfirmation : AdvantShopClientPage
    {
        public int ProductId;
        public List<CustomOption> CustomOptions;
        public List<OptionItem> SelectedOptions;
        public bool isShoppingCart = false;

        public int OrderID { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request["step"] == "FinalTab")
                {
                    mvOrderConfirmation.SetActiveView(success);
                    OrderID = Session["OrderID"].ToString().TryParseInt();
                    var order = OrderService.GetOrder(OrderID);

                    if (order == null)
                        return;

                    if (GoogleTagManager.Enabled)
                    {
                        var tagManager = ((AdvantShopMasterPage)Master).TagManager;
                        tagManager.PageType = GoogleTagManager.ePageType.purchase;
                        tagManager.ProdIds = ShoppingCartService.CurrentShoppingCart.Select(item => item.Offer.ArtNo).ToList();
                        tagManager.TotalValue = ShoppingCartService.CurrentShoppingCart.TotalPrice;

                        tagManager.Transaction = new Transaction()
                        {
                            TransactionAffiliation = SettingsMain.ShopName,
                            TransactionId = order.OrderID,
                            TransactionTotal = order.Sum - order.ShippingCost,
                            TransactionShipping = order.ShippingCost,
                            TransactionProducts =
                                new List<TransactionProduct>(
                                    order.OrderItems.Select(
                                        item =>
                                        new TransactionProduct()
                                        {
                                            Name = item.Name,
                                            Price = item.Price,
                                            Quantity = item.Amount,
                                            SKU = item.ArtNo,
                                            Category =
                                                CategoryService.GetCategory(
                                                    ProductService.GetFirstCategoryIdByProductId((int)item.ProductID)).Name
                                        }))
                        };

                    }

                    ShoppingCartService.ClearShoppingCart(ShoppingCartType.ShoppingCart);

                }
                else
                {
                    mvOrderConfirmation.SetActiveView(form);
                    txtPhone.Text = CustomerContext.CurrentCustomer.Phone;
                    txtName.Text = CustomerContext.CurrentCustomer.FirstName + " " + CustomerContext.CurrentCustomer.LastName;

                    if (GoogleTagManager.Enabled)
                    {
                        var tagManager = ((AdvantShopMasterPage)Master).TagManager;
                        tagManager.PageType = GoogleTagManager.ePageType.order;
                        tagManager.ProdIds = ShoppingCartService.CurrentShoppingCart.Select(item => item.Offer.ArtNo).ToList();
                        tagManager.TotalValue = ShoppingCartService.CurrentShoppingCart.TotalPrice;
                    }
                }
            }

            

        }

        protected void btnBuyInOneClick_OnClick(object sender, EventArgs e)
        {
            if (txtName.Text.IsNullOrEmpty() || txtPhone.Text.IsNullOrEmpty())
            {
                errorMsg.Text = Resources.Resource.Client_OneClick_WrongData;
                return;
            }

            var shoppingCart = ShoppingCartService.CurrentShoppingCart;
            float totalPrice = shoppingCart.TotalPrice;
            float discountPercentOnTotalPrice = shoppingCart.DiscountPercentOnTotalPrice;

            if (shoppingCart.TotalPrice < AdvantShop.Configuration.SettingsOrderConfirmation.MinimalOrderPrice)
            {
                errorMsg.Text = string.Format(Resources.Resource.Client_ShoppingCart_MinimalOrderPrice,
                                              CatalogService.GetStringPrice(
                                                  AdvantShop.Configuration.SettingsOrderConfirmation
                                                            .MinimalOrderPrice),
                                              CatalogService.GetStringPrice(
                                                  AdvantShop.Configuration.SettingsOrderConfirmation
                                                            .MinimalOrderPrice - totalPrice));
                return;
            }

            var orderItems = shoppingCart.Select(item => (OrderItem) item).ToList();

            OrderCertificate orderCertificate = null;
            OrderCoupon orderCoupon = null;

            GiftCertificate certificate = shoppingCart.Certificate;
            Coupon coupon = shoppingCart.Coupon;

            if (certificate != null)
            {
                orderCertificate = new OrderCertificate()
                    {
                        Code = certificate.CertificateCode,
                        Price = certificate.Sum
                    };
            }
            if (coupon != null && shoppingCart.TotalPrice >= coupon.MinimalOrderPrice)
            {
                orderCoupon = new OrderCoupon()
                    {
                        Code = coupon.Code,
                        Type = coupon.Type,
                        Value = coupon.Value
                    };
            }

            var orderContact = new OrderContact
                {
                    Address = string.Empty,
                    City = string.Empty,
                    Country = string.Empty,
                    Name = string.Empty,
                    Zip = string.Empty,
                    Zone = string.Empty
                };
            
            var customerGroup = CustomerContext.CurrentCustomer.CustomerGroup;

            var baseCurrency = CurrencyService.BaseCurrency;

            var order = new Order
                {
                    CustomerComment = txtComment.Text,
                    OrderDate = DateTime.Now,
                    OrderCurrency = new OrderCurrency
                        {
                            //CurrencyCode = CurrencyService.CurrentCurrency.Iso3,
                            //CurrencyNumCode = CurrencyService.CurrentCurrency.NumIso3,
                            //CurrencySymbol = CurrencyService.CurrentCurrency.Symbol,
                            //CurrencyValue = CurrencyService.CurrentCurrency.Value,
                            //IsCodeBefore = CurrencyService.CurrentCurrency.IsCodeBefore
                            CurrencyCode = baseCurrency.Iso3,
                            CurrencyValue = baseCurrency.Value,
                            CurrencySymbol = baseCurrency.Symbol,
                            CurrencyNumCode = baseCurrency.NumIso3,
                            IsCodeBefore = baseCurrency.IsCodeBefore
                        },
                    OrderCustomer = new OrderCustomer
                        {
                            CustomerID = CustomerContext.CurrentCustomer.Id,
                            Email = CustomerContext.CurrentCustomer.EMail,
                            FirstName = txtName.Text,
                            LastName = string.Empty,
                            MobilePhone = txtPhone.Text,
                            CustomerIP = HttpContext.Current.Request.UserHostAddress
                        },

                    OrderStatusId = OrderService.DefaultOrderStatus,
                    AffiliateID = 0,
                    GroupName = customerGroup.GroupName,
                    GroupDiscount = customerGroup.GroupDiscount,


                    OrderItems = orderItems,
                    OrderDiscount = discountPercentOnTotalPrice,
                    Number = OrderService.GenerateNumber(1),
                    ShippingContact = orderContact,
                    BillingContact = orderContact,
                    Certificate = orderCertificate,
                    Coupon = orderCoupon,
                    AdminOrderComment = Resources.Resource.Client_BuyInOneClick_Header
                };

            order.OrderID = OrderService.AddOrder(order);
            order.Number = OrderService.GenerateNumber(order.OrderID);
            OrderService.UpdateNumber(order.OrderID, order.Number);
            OrderService.ChangeOrderStatus(order.OrderID, OrderService.DefaultOrderStatus);

            if (order.OrderID != 0)
            {
                var orderTable = OrderService.GenerateHtmlOrderTable(order.OrderItems,
                                                                     CurrencyService.CurrentCurrency, totalPrice,
                                                                     discountPercentOnTotalPrice, orderCoupon,
                                                                     orderCertificate,
                                                                     discountPercentOnTotalPrice > 0
                                                                         ? discountPercentOnTotalPrice*totalPrice/100
                                                                         : 0, 0, 0, 0, 0, 0);
                var mailTemplate = new BuyInOneClickMailTemplate(order.OrderID.ToString(),
                                                                 HttpUtility.HtmlEncode(txtPhone.Text),
                                                                 HttpUtility.HtmlEncode(txtName.Text),
                                                                 HttpUtility.HtmlEncode(txtComment.Text),
                                                                 orderTable, order.Number);

                mailTemplate.BuildMail();
                SendMail.SendMailNow(SettingsMail.EmailForOrders, mailTemplate.Subject, mailTemplate.Body, true);
            }

            ModulesRenderer.OrderAdded(order.OrderID);

            if (order.OrderID != 0)
            {
                Session["OrderId"] = order.OrderID;
                Response.Redirect("~/orderconfirmation.aspx?step=FinalTab");
            }
            else
            {
                errorMsg.Text = Resources.Resource.Client_ShoppingCart_Error;
            }
        }
    }
}