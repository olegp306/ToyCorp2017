//--------------------------------------------------
// Project: AdvantShop.NET
// Web site: http:\\www.advantshop.net
//--------------------------------------------------

using System;
using AdvantShop.Controls;
using AdvantShop.News;
using AdvantShop.SEO;

namespace Templates.Mobile
{
    public partial class NewsView : AdvantShopClientPage
    {
        public string StrMainText = string.Empty;
        public string StrTitleText = string.Empty;
        public string StrAnnotationText = string.Empty;
        protected string SPhoto;
        protected int NewsID = 0;

        protected NewsItem NewsItem;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Page.Request["newsid"]))
            {
                this.Error404();
                return;
            }

            int tempId;
            Int32.TryParse(Page.Request["newsid"], out tempId);

            NewsItem = NewsService.GetNewsById(tempId);

            if (NewsItem == null)
            {
                this.Error404();
                return;
            }

            SetMeta(NewsItem.Meta, NewsItem.Title);
            StrTitleText = NewsItem.Title;
            StrAnnotationText = NewsItem.TextAnnotation;
            StrMainText = NewsItem.TextToPublication;

            if (GoogleTagManager.Enabled)
            {
                var tagManager = ((AdvantShopMasterPage)Master).TagManager;
                tagManager.PageType = GoogleTagManager.ePageType.info;
            }
        }

    }
}